

@XmlSchema(
namespace = "http://www.sat.gob.mx/nomina",
elementFormDefault = XmlNsForm.QUALIFIED,
xmlns={@XmlNs(prefix="nomina", namespaceURI="http://www.sat.gob.mx/nomina")})  

package mx.xpd.cfdi.domain.cfdi.complementos.nomina;
import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
