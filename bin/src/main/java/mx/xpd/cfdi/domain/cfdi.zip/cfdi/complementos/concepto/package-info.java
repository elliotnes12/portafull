

@XmlSchema(
namespace = "http://www.sat.gob.mx/iedu", 
//elementFormDefault = XmlNsForm.QUALIFIED,
xmlns={@XmlNs(prefix="iedu", namespaceURI="http://www.sat.gob.mx/iedu")})  

package mx.xpd.cfdi.domain.cfdi.complementos.concepto;
import javax.xml.bind.annotation.*;