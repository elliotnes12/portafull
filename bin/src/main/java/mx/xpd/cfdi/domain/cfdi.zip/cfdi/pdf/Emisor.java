package mx.xpd.cfdi.domain.cfdi.pdf;

import java.util.ArrayList;
import java.util.List;

import mx.xpd.cfdi.domain.cfdi.TUbicacion;
import mx.xpd.cfdi.domain.cfdi.pdf.RegimenFiscal;

import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Emisor {
	
	private String rfc;
	private String nombre;
	private String email;
	private TUbicacion domicilioFiscal;
	private TUbicacion expedidoEn;
	private List<RegimenFiscal> regimenFiscal;
	
	public Emisor() {
		regimenFiscal = new ArrayList<RegimenFiscal>();
	}
	
	@XmlElement(name = "ExpedidoEn")
	public TUbicacion getExpedidoEn() {
		return expedidoEn;
	}
	@XmlElement(name = "RegimenFiscal")
	public List<RegimenFiscal> getRegimenFiscal() {
		return regimenFiscal;
	}
	@XmlElement(name = "DomicilioFiscal")
	public TUbicacion getDomicilioFiscal() {
		return domicilioFiscal;
	}
	@XmlAttribute
	public String getRfc() {
		return rfc;
	}
	@XmlAttribute
	public String getNombre() {
		return nombre;
	}
	@Transient
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public void setExpedidoEn(TUbicacion expedidoEn) {
		this.expedidoEn = expedidoEn;
	}

	public void setRegimenFiscal(List<RegimenFiscal> regimenFiscal) {
		this.regimenFiscal = regimenFiscal;
	}
	public void setDomicilioFiscal(TUbicacion domicilioFiscal) {
		this.domicilioFiscal = domicilioFiscal;
	}
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Emisor [rfc=" + rfc + ", nombre=" + nombre + "]";
	}
	
	
}