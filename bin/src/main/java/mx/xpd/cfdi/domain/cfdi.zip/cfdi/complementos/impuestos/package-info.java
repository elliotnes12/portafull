

@XmlSchema(
namespace = "http://www.sat.gob.mx/implocal",
elementFormDefault = XmlNsForm.QUALIFIED,
xmlns={@XmlNs(prefix="implocal", namespaceURI="http://www.sat.gob.mx/implocal")})  

package mx.xpd.cfdi.domain.cfdi.complementos.impuestos;
import javax.xml.bind.annotation.*;