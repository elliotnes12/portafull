	package mx.xpd.cfdi.domain.cfdi;

import javax.validation.constraints.DecimalMax;
import javax.xml.bind.annotation.XmlAttribute;

public class Impuesto {

	private String impuesto;
	private String tasa;
	private String importe;
	
	
	
	@XmlAttribute
	public String getImpuesto() {
		return impuesto;
	}
	@XmlAttribute
	public String getTasa() {
		if (tasa.equals("0")) {
			return "0.00";
		}
		return tasa;
	}
	@XmlAttribute
	@DecimalMax(value = "6")
	public String getImporte() {
		if (importe == null && tasa != null && tasa.equals("0")) {
			return "0.00";
		}
		if (tasa.equals("0")) {
			return "0.00";
		}
		return importe;
	}
	public void setImpuesto(String impuesto) {
		this.impuesto = impuesto;
	}
	public void setTasa(String tasa) {
		this.tasa = tasa;
	}
	public void setImporte(String importe) {
		this.importe = importe;
	}
	
}
