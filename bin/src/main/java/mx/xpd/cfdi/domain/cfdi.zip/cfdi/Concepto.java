package mx.xpd.cfdi.domain.cfdi;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import mx.xpd.cfdi.domain.cfdi.complementos.concepto.ComplementoConcepto;


public class Concepto {

	private Double cantidad;
	private String unidad;
	private String clave;
	private String descripcion;
	private String valorUnitario;
	private String importe;
	private ComplementoConcepto complementoConcepto;
	
	public Concepto() {
		this.complementoConcepto = new ComplementoConcepto();
	}
	
	@Override
	public String toString() {
		return "Concepto [cantidad=" + cantidad + ", unidad=" + unidad
				+ ", noIdentificacion=" + clave + ", descripcion="
				+ descripcion + ", valorUnitario=" + valorUnitario
				+ ", importe=" + importe + "]";
	}
	@XmlElement(name = "ComplementoConcepto")
	public ComplementoConcepto getComplementoConcepto() {
		if (complementoConcepto.getInstEducativas() == null) {
			return null;
		}
		return complementoConcepto;
	}
	@XmlAttribute
	public Double getCantidad() {
		return cantidad;
	}
	@XmlAttribute
	public String getUnidad() {
		return unidad;
	}
	@XmlAttribute(name = "noIdentificacion")
	public String getClave() {
		return clave;
	}
	@XmlAttribute
	public String getDescripcion() {
		return descripcion;
	}
	@XmlAttribute
	public String getValorUnitario() {
		return valorUnitario;
	}
	@XmlAttribute
	public String getImporte() {
		return importe;
	}
	/**********************/
	public void getComplementoConcepto(ComplementoConcepto complementoConcepto) {
		this.complementoConcepto = complementoConcepto;
	}
	public void setCantidad(Double cantidad) {
		this.cantidad = cantidad;
	}
	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public void setValorUnitario(String valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	public void setImporte(String importe) {
		this.importe = importe;
	}
	
	
	
}
