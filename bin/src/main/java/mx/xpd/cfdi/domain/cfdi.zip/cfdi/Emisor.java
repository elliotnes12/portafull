package mx.xpd.cfdi.domain.cfdi;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Emisor {
	
	private String rfc;
	private String nombre;
	private TUbicacion domicilioFiscal;
	private TUbicacion expedidoEn;
	
	private List<RegimenFiscal> regimenFiscal;
	
	
	public Emisor() {
		regimenFiscal = new ArrayList<RegimenFiscal>();
	}
	
	@XmlElement(name = "RegimenFiscal")
	public List<RegimenFiscal> getRegimenFiscal() {
		return regimenFiscal;
	}
	@XmlElement(name = "DomicilioFiscal")
	public TUbicacion getDomicilioFiscal() {
		return domicilioFiscal;
	}
	@XmlElement(name = "ExpedidoEn")
	public TUbicacion getExpedidoEn() {
		return expedidoEn;
	}
	@XmlAttribute
	public String getRfc() {
		return rfc;
	}
	@XmlAttribute
	public String getNombre() {
		return nombre;
	}
	public void setExpedidoEn(TUbicacion expedidoEn) {
		this.expedidoEn = expedidoEn;
	}
	public void setRegimenFiscal(List<RegimenFiscal> regimenFiscal) {
		this.regimenFiscal = regimenFiscal;
	}
	public void setDomicilioFiscal(TUbicacion domicilioFiscal) {
		this.domicilioFiscal = domicilioFiscal;
	}
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Emisor [rfc=" + rfc + ", nombre=" + nombre + "]";
	}
	
}