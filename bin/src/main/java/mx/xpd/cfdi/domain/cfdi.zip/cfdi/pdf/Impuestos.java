package mx.xpd.cfdi.domain.cfdi.pdf;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class Impuestos {
	
	private Traslados traslados;
	private Retenidos retenidos;
	
	private Double totalImpuestosRetenidos;
	private Double totalImpuestosTrasladados;
	
	@XmlElement(name = "Traslados")
	public Traslados getTraslados() {
		return traslados;
	}
	@XmlElement(name = "Retenciones")
	public Retenidos getRetenidos() {
		return retenidos;
	}

	public void setRetenidos(Retenidos retenidos) {
		this.retenidos = retenidos;
	}

	@XmlAttribute
	public Double getTotalImpuestosRetenidos() {
		return totalImpuestosRetenidos;
	}
	@XmlAttribute
	public Double getTotalImpuestosTrasladados() {
		return totalImpuestosTrasladados;
	}
	
	

	public void setTotalImpuestosRetenidos(Double totalImpuestosRetenidos) {
		this.totalImpuestosRetenidos = totalImpuestosRetenidos;
	}

	public void setTotalImpuestosTrasladados(Double totalImpuestosTrasladados) {
		this.totalImpuestosTrasladados = totalImpuestosTrasladados;
	}

	public void setTraslados(Traslados traslados) {
		this.traslados = traslados;
	}
	
	
	
	
	
}
