package mx.xpd.cfdi.domain.cfdi.pdf;


public class RegimenFiscal extends mx.xpd.cfdi.domain.cfdi.RegimenFiscal {

	
}
