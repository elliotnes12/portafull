package mx.xpd.cfdi.domain.cfdi.pdf;

import javax.xml.bind.annotation.XmlAttribute;

public class Impuesto {

	private String impuesto;
	private Double tasa;
	private Double importe;
	
	@XmlAttribute
	public String getImpuesto() {
		return impuesto;
	}
	@XmlAttribute
	public Double getTasa() {
		return tasa;
	}
	@XmlAttribute
	public Double getImporte() {
		return importe;
	}
	public void setImpuesto(String impuesto) {
		this.impuesto = impuesto;
	}
	public void setTasa(Double tasa) {
		this.tasa = tasa;
	}
	public void setImporte(Double importe) {
		this.importe = importe;
	}

	
	
	
}
