package mx.xpd.cfdi.domain.cfdi.pdf;

import javax.xml.bind.annotation.XmlElement;

import mx.xpd.cfdi.domain.cfdi.pdf.complementos.donatarias.Donatarias;
import mx.xpd.cfdi.domain.cfdi.pdf.complementos.impuestos.ImpuestosLocales;
import mx.xpd.cfdi.domain.cfdi.pdf.complementos.nomina.Nomina;
import mx.xpd.cfdi.domain.cfdi.pdf.timbre.TimbreFiscalDigital;

public class Complemento {
	
	private TimbreFiscalDigital timbreFiscalDigital;
	private ImpuestosLocales impuestosLocales;
	private Donatarias donatarias;
	private Nomina nomina;
	

	
	@XmlElement(name = "TimbreFiscalDigital")
	public TimbreFiscalDigital getTimbreFiscalDigital() {
		return timbreFiscalDigital;
	}
	@XmlElement(name = "ImpuestosLocales")
	public ImpuestosLocales getImpuestosLocales() {
		return impuestosLocales;
	}
	@XmlElement(name = "Donatarias")
	public Donatarias getDonatarias() {
		return donatarias;
	}
	@XmlElement(name = "Nomina")
	public Nomina getNomina() {
		return nomina;
	}
	public void setNomina(Nomina nomina) {
		this.nomina = nomina;
	}
	public void setDonatarias(Donatarias donatarias) {
		this.donatarias = donatarias;
	}
	public void setTimbreFiscalDigital(TimbreFiscalDigital timbreFiscalDigital) {
		this.timbreFiscalDigital = timbreFiscalDigital;
	}
	public void setImpuestosLocales(ImpuestosLocales impuestosLocales) {
		this.impuestosLocales = impuestosLocales;
	}
	
	
}
