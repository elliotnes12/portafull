package mx.xpd.cfdi.domain.cfdi.pdf;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Retenidos {
	private List<Retencion> retenciones;

	public Retenidos() {
		retenciones = new ArrayList<Retencion>();
	}
	@XmlElement(name = "Retencion")
	public List<Retencion> getRetenciones() {
		return retenciones;
	}

	public void setRetenciones(List<Retencion> retenciones) {
		this.retenciones = retenciones;
	}

	
	
	
}
