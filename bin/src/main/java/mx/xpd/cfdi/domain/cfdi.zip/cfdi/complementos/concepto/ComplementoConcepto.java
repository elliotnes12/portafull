package mx.xpd.cfdi.domain.cfdi.complementos.concepto;

import javax.xml.bind.annotation.XmlElement;



public class ComplementoConcepto {

	private InstitucionesEducativasPrivadas instEducativas;
	
	public ComplementoConcepto() {
		this.instEducativas = new InstitucionesEducativasPrivadas();
	}

	@XmlElement(name = "instEducativas")
	public InstitucionesEducativasPrivadas getInstEducativas() {
		
		if (instEducativas.getCurp() == null || instEducativas.getAutRVOE() == null) {
			return null;
		}
		
		return instEducativas;
	}

	public void setInstEducativas(InstitucionesEducativasPrivadas instEducativas) {
		this.instEducativas = instEducativas;
	}
	
	
	
}
