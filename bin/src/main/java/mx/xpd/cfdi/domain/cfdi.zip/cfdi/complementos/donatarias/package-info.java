

@XmlSchema(
namespace = "http://www.sat.gob.mx/donat",
//elementFormDefault = XmlNsForm.QUALIFIED,
xmlns={@XmlNs(prefix="donat", namespaceURI="http://www.sat.gob.mx/donat")})  

package mx.xpd.cfdi.domain.cfdi.complementos.donatarias;
import javax.xml.bind.annotation.*;