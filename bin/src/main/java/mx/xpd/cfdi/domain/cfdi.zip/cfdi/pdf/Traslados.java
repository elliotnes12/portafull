package mx.xpd.cfdi.domain.cfdi.pdf;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Traslados {
	
	private List<Impuesto> traslados;

	public Traslados() {
		traslados = new ArrayList<Impuesto>();
	}

	@XmlElement(name = "Traslado")
	public List<Impuesto> getTraslados() {
		return traslados;
	}

	public void setTraslados(List<Impuesto> traslados) {
		this.traslados = traslados;
	}
	
	
	
}
