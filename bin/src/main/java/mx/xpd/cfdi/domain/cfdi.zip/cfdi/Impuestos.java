package mx.xpd.cfdi.domain.cfdi;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class Impuestos {
	
	private Traslados traslados;
	private Retenidos retenidos;
	
	private String totalImpuestosRetenidos;
	private String totalImpuestosTrasladados;
	
	
	
	@XmlElement(name = "Traslados")
	public Traslados getTraslados() {
		return traslados;
	}
	
	@XmlElement(name = "Retenciones")
	public Retenidos getRetenidos() {
		return retenidos;
	}


	@XmlAttribute
	public String getTotalImpuestosRetenidos() {
		if (totalImpuestosRetenidos == null || totalImpuestosRetenidos.equals("0")) {
			return "0.00";
		}
		return totalImpuestosRetenidos;
	}
	@XmlAttribute
	public String getTotalImpuestosTrasladados() {
		if (totalImpuestosTrasladados == null || totalImpuestosTrasladados.equals("0")) {
			return "0.00";
		}
		return totalImpuestosTrasladados;
	}
	
	

	public void setRetenidos(Retenidos retenidos) {
		this.retenidos = retenidos;
	}


	public void setTotalImpuestosRetenidos(String totalImpuestosRetenidos) {
		this.totalImpuestosRetenidos = totalImpuestosRetenidos;
	}

	public void setTotalImpuestosTrasladados(String totalImpuestosTrasladados) {
		this.totalImpuestosTrasladados = totalImpuestosTrasladados;
	}

	public void setTraslados(Traslados traslados) {
		this.traslados = traslados;
	}
	
	
	
	
	
}
