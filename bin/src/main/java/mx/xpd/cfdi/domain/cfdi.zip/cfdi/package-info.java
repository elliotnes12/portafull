

@XmlSchema(
namespace = "http://www.sat.gob.mx/cfd/3",
elementFormDefault = XmlNsForm.QUALIFIED,
xmlns={@XmlNs(prefix="cfdi", namespaceURI="http://www.sat.gob.mx/cfd/3")})  

package mx.xpd.cfdi.domain.cfdi;
import javax.xml.bind.annotation.*;